# SMFluxBridge™ 1.1.1

## Discord DM diagnostics hotfix

- Preserves all SMFluxBridge™ 1.1.0 subscription, Discord-link, SignalR, and durable-journal behavior.
- Discord DM channel creation failures now capture the HTTP status and Discord numeric error code/message when provided.
- Discord DM message-send failures now capture the same sanitized diagnostics.
- `/discordlink` reports the sanitized failure detail to the requesting player.
- The server console now records one concise sanitized failure line for a failed link-code DM.
- SMCore diagnostics receive the same sanitized detail.
- Bot tokens, FluxStore credentials, verification codes, channel response bodies, and Authorization headers are never intentionally logged.
