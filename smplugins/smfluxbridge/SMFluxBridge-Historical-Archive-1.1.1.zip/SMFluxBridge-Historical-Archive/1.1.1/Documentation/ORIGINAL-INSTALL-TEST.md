# Install / test

1. Stop the server.
2. Replace only the old SMFluxBridge JAR with `SMFluxBridge-1.1.1.jar`.
3. Keep the existing `plugins/SMFluxBridge/config.yml`, `journal.yml`, Discord links, reminder state, and other data files.
4. Start the server and run `/smfluxbridge status`; verify Version is 1.1.1.
5. Retry `/discordlink <your numeric Discord user ID>` once.
6. If Discord rejects the request, capture only the sanitized line similar to `Discord DM failed: HTTP 403 / code 50007 / Cannot send messages to this user.` Never share tokens or config secrets.

Rollback: stop server and restore the 1.1.0 JAR. No config/data migration is performed by 1.1.1.
