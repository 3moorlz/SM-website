# SMFluxBridge™ 1.2.1 — SignalR Handshake Diagnostics Hotfix

## Changed
- WebSocket upgrade failures now retain the HTTP handshake status in diagnostics/status output.
- The logged endpoint is sanitized to scheme + host + path only; connection IDs/tokens, bearer tokens, headers, and bodies are not logged.
- SignalR User-Agent updated to SMFluxBridge/1.2.1.

## Unchanged
- FluxStore command journal and no-blind-replay safety.
- Subscription synchronization and reminders.
- Discord linking, linked-account registry, Ticket Tool role synchronization, slash command, and synthetic notification tests.
- Configuration schema and persistent data formats.

## Purpose
The prior 1.2.0 status only surfaced `WebSocketHandshakeException: null`, which hid the HTTP response code needed to distinguish endpoint/authentication/proxy failures.
