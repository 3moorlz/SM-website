# Install / Test — SMFluxBridge™ 1.2.1

1. Stop the server.
2. Replace SMFluxBridge-1.2.0.jar with SMFluxBridge-1.2.1.jar.
3. Keep the existing plugins/SMFluxBridge/ directory and config.yml unchanged.
4. Start the server.
5. Run `/smfluxbridge status`.
6. If still disconnected, run `/smfluxbridge reconnect`, wait ~10 seconds, then run `/smfluxbridge status` again.
7. Report only the sanitized `Last transport error` line. Never share server keys, API keys, Discord bot tokens, or full configs.

Expected diagnostic improvement: instead of `WebSocketHandshakeException: null`, status should include `SignalR WebSocket handshake HTTP <status> at wss://api.fluxstore.net/plugin-hub`.
