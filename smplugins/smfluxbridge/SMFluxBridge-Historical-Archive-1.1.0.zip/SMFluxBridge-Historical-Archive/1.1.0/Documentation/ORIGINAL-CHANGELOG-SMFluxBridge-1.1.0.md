# SMFluxBridge™ 1.1.0 — Subscription Lifecycle & Discord Alerts

## Added
- FluxStore subscription REST synchronization using API-key authentication.
- Reads renewal timing from `currentPeriodEnd` when present.
- Tolerant field parsing for common camelCase/snake_case API layouts without
  requiring undocumented fields.
- Configurable reminder thresholds (30d/14d/7d/3d/1d/12h/1h defaults).
- Durable reminder deduplication per subscription renewal cycle.
- `/subscription` player command for synchronized status + live renewal timer.
- Optional near-renewal boss-bar countdown.
- In-game chat/action-bar renewal reminders.
- Subscription lifecycle detection: renewed, active, past due, cancelled, expired,
  and generic status changes.
- Secure `/discordlink` DM-code flow. Verification codes are random, short-lived,
  single-use, and only SHA-256 hashes are persisted.
- Discord DM renewal and lifecycle alerts using a server-local Discord bot token.
- Optional use of a trusted FluxStore-linked Discord ID when the API response
  contains one; locally verified links take priority.
- Public `SubscriptionLifecycleEvent` so SMAdmin™ or other SM Suite™ modules can
  consume normalized subscription events later without scraping logs.
- `/smfluxbridge subscriptionsync` admin command.
- Subscription API / Discord DM health in `/smfluxbridge status`.

## Preserved
- 1.0.1 SignalR keepalive/reconnect stability behavior.
- 1.0.0 durable command execution journal and UNCERTAIN/manual-review semantics.
- FluxStore command delivery protocol and acknowledgement behavior.
- Credential/command redaction policy.

## Important boundary
FluxStore's owner confirmed renewal-failure/past-due webhook work is in progress.
This build does not invent or bind to an unpublished webhook schema. It detects
lifecycle state through the subscription API now and is structured for a future
webhook adapter once FluxStore publishes the event contract.
