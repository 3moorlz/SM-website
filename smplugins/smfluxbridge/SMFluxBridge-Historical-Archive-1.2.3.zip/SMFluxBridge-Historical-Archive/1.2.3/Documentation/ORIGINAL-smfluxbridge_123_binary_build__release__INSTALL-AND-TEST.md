# SMFluxBridge™ 1.2.3 Install / Test

1. Stop the server completely.
2. Remove the prior SMFluxBridge JAR from `/plugins`.
3. Upload `SMFluxBridge-1.2.3.jar`.
4. Keep the existing `plugins/SMFluxBridge/` directory and configuration unchanged.
5. Start the server.
6. Run `/smfluxbridge status`.

Expected success:
- Version: 1.2.3
- FluxStore: connected
- Transport stage: authenticated
- Store: populated
- Last transport error: n/a

Do not paste any server key, FluxStore API key, Discord bot token, verification code, or SignalR connection token into support logs/chat.

Rollback: stop the server, restore the previous JAR, and leave the plugin data folder unchanged.
