# SMFluxBridge™ 1.2.3 — SignalR Binary Frame Parity Hotfix

## Fixed
- Matches the official FluxStore 1.0.0 reference client's Microsoft SignalR WebSocket transport by sending JSON hub-protocol payloads as binary UTF-8 WebSocket frames.
- Handles both binary and text inbound SignalR frames.
- Retains 1.2.2 negotiate/cookie/connection-token/access-token parity.
- Preserves 1.2.x linked-account registry, Discord role sync, slash lookup, Ticket Tool gating support, subscriptions, reminders, lifecycle tests, diagnostics, and durable command journal.

## Safety / migration
- No config migration.
- No storage migration.
- Existing linked accounts remain intact.
- Existing journal and subscription reminder state remain intact.
- No credentials are included in this package.
