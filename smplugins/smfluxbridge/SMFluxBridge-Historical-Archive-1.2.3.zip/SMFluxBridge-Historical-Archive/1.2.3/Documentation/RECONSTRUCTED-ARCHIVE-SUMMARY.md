# RECONSTRUCTED — SMFluxBridge 1.2.3 Archive Summary
This supplemental archive note is not an original historical file.
Recovered release role: SignalR binary parity hotfix.
