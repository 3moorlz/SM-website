# SMFluxBridge™ 1.2.0 — Linked Identity Release

Authors: G660 & Vaporeon  
Website: https://smsmp.net  
Target: Purpur 1.21.11 / Java 21 / SMCore 1.2.1

## Added
- Persistent one-to-one Minecraft UUID ↔ Discord User ID identity registry.
- Backward-compatible enrichment of existing `discord-links.yml` records.
- Staff in-game `/linkedaccount <IGN>` lookup.
- Staff Discord `/linkedaccount user:@User` or `/linkedaccount id:<ID>` guild slash command.
- Minimal Discord Gateway connection so the bot can receive interactions and show online presence.
- Configurable Discord staff role IDs plus optional Discord Administrator access for slash lookup.
- Automatic configurable `Linked Account` Discord role grant on verified link.
- Conservative unlink flow: when role gating is configured, the Discord role must be removed before local unlink commits.
- `/smfluxbridge linksync` to reconcile the Linked Account role for all known links.
- Public read-only `SMFluxBridgeAPI` with `isLinked`, `getByMinecraft`, and `getByDiscord` for future SMCosmetics™ and other SM Suite™ modules.
- Safe synthetic subscription notification tests:
  - reminder thresholds
  - renewed
  - past due
  - cancelled
  - expired
  - active
- Linked-account lookup and role-sync audit events through SMCore™ → SMAudit™.
- Linked account count, role-sync configuration, and Discord Gateway status in `/smfluxbridge status`.

## Security / reliability
- Verification codes remain SHA-256 hashed at rest, single-use, and short-lived.
- One Discord account cannot be linked to multiple Minecraft UUIDs.
- One Minecraft UUID cannot silently switch Discord ownership without unlinking first.
- Discord lookup responses are staff-gated; Discord slash responses are ephemeral.
- Bot token, API keys, verification-code plaintext, payment details, and raw Discord error bodies are not included in identity records or audit payloads.
- Synthetic subscription tests do not modify FluxStore, billing data, real renewal dates, reminder dedupe markers, or production lifecycle state.
- Existing FluxStore command journal / UNCERTAIN semantics and 1.1.1 sanitized Discord diagnostics remain intact.

## Ticket Tool integration
SMFluxBridge™ does not modify Ticket Tool. Instead, configure a Discord `Linked Account` role and set that role as an Allowed User Role in the desired Ticket Tool category. SMFluxBridge grants/removes the role based on verified account-link state.
