# SMFluxBridge™ 1.0.0 — Initial Release

## Purpose

First-party game-side FluxStore bridge for SM Suite™.

## FluxStore protocol

- Implements the documented FluxStore SignalR/WebSocket plugin protocol.
- Authenticates with the FluxStore server key before any plugin hub method calls.
- Handles `PlayerJoin`, `PlayerLeave`, `FetchPendingCommands`,
  `AcknowledgeCommands`, and server-pushed `ExecuteCommands`.
- Sorts deliveries by `ExecutionOrder`.
- Honors `RequireOnline`, `Conditions.Slots`, and `Conditions.DelaySeconds`.
- Uses FluxStore's returned `NextCheckSeconds` as a hard lower bound for fallback polling.
- Reconnects with exponential backoff and jitter instead of a tight reconnect loop.

## Reliability / duplicate protection

- Durable local `journal.yml` records command IDs before console dispatch.
- Successful command IDs are retained so a reconnect/re-delivery does not blindly replay a confirmed local success.
- A command left in `EXECUTING` across a restart is promoted to `UNCERTAIN`.
- `UNCERTAIN` commands are never automatically replayed or acknowledged.
- `/smfluxbridge resolve <id> <success|retry|failed>` provides an explicit manual recovery path.
- If the journal cannot be persisted before dispatch, execution is blocked.
- If a command is accepted by Bukkit but the SUCCESS journal state cannot be durably persisted, acknowledgement stops and manual review is required.
- A false Bukkit dispatch result defaults to `UNCERTAIN`, not automatic retry.

## Security

- Supports environment-variable credentials (`FLUXSTORE_SERVER_KEY`) as the preferred deployment path.
- Config-based server key remains available for normal server hosting environments.
- Full server keys/secrets are never intentionally logged or emitted into SMAudit™.
- Full FluxStore command strings are not emitted into structured audit events; SHA-256, command ID, target, package/type, result, and recovery state are used instead.
- Newlines/NULs and oversized commands are rejected before dispatch.
- Destructive console roots are blocked by default: stop, minecraft:stop, restart, reload, rl, op, deop.
- Online UUID/name identity is rechecked before player-dependent execution.
- Slot and online conditions are rechecked after delayed-command waits.

## SM Suite™ integration

- Hard dependency on SMCore 1.2.1.
- Structured SMCore audit events.
- SMCore diagnostics for connection, protocol, journal, delivery, and uncertain-execution failures.
- Forced SMAudit™ v2 route categories for transactions, gameplay, administration, configuration, and security where appropriate.

## Administration

`/smfluxbridge status`
`/smfluxbridge reload`
`/smfluxbridge reconnect`
`/smfluxbridge fetch`
`/smfluxbridge journal [page]`
`/smfluxbridge resolve <commandId> <success|retry|failed>`
`/smfluxbridge diagnosetest`

Permission: `smfluxbridge.admin`
