# RECONSTRUCTED — SMFluxBridge 1.0.0 Testing Supplement
1. Verify `/version SMFluxBridge` reports 1.0.0.
2. Use non-production/test credentials or a controlled staging connection.
3. Verify `/smfluxbridge status` never exposes credential material.
4. Verify SignalR/WebSocket connection and reconnect behavior relevant to this version.
5. Verify durable command journal/replay safety where supported.
6. Verify `/subscription`, `/discordlink`, and Discord linked-account behavior on versions that expose them.
7. Exercise one safe diagnostic test where supported and confirm audit/diagnostic routing.
8. Confirm duplicate/replayed commands cannot double-grant fulfillment.
