# SMFluxBridge™ 1.2.2 — FluxStore SignalR Reference-Parity Hotfix

## Fixed
- Matched the connection mechanics observed in the user-supplied official FluxStore 1.0.0 plugin reference implementation.
- Preserves cookies set during SignalR negotiation and reuses them for the WebSocket upgrade.
- Appends the negotiated SignalR connection token verbatim as the `id` query value rather than URL-encoding it again.
- Carries a negotiate `accessToken` into the WebSocket Authorization header when FluxStore supplies one.
- Verifies that the negotiate response advertises WebSockets before attempting the WebSocket transport.
- Authenticate payload now includes `pluginVersion`, `serverSoftware`, `onlinePlayers`, and `maxPlayers`, matching the official client payload shape.
- Retains 1.2.1 sanitized HTTP handshake diagnostics.

## Preserved
- FluxStore subscription REST synchronization.
- Discord account linking and Linked Account role sync.
- Discord staff `/linkedaccount` lookup and in-game `/linkedaccount` lookup.
- Synthetic subscription notification tests.
- Durable command journal and no-blind-replay safeguards.
- Existing production config and stored linked-account/subscription state.

## Migration
No config, journal, linked-account, subscription, or storage migration is required. Replace the JAR and keep the existing `plugins/SMFluxBridge/` directory.
