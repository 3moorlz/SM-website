# SMFluxBridge™ 1.2.2 Install / Test

1. Stop the Minecraft server completely.
2. Remove the old `SMFluxBridge-1.2.1.jar` from `/plugins`.
3. Upload `SMFluxBridge-1.2.2.jar`.
4. Keep the existing `plugins/SMFluxBridge/` directory and config unchanged.
5. Start the server.
6. Run `/smfluxbridge status` after startup.
7. Expected success:
   - Version: 1.2.2
   - FluxStore: connected
   - Transport stage: authenticated
   - Store: populated with the FluxStore store name
   - Last transport error: n/a
8. If it still fails, copy only `/smfluxbridge status` and the sanitized SMFluxBridge transport error. Never paste server keys, API keys, Discord bot tokens, or SignalR connection tokens.

Rollback: stop the server, restore the prior JAR, and leave the plugin data folder unchanged.
