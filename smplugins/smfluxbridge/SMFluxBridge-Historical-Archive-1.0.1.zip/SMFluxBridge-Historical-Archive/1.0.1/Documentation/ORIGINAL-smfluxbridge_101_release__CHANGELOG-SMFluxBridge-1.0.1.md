# SMFluxBridge™ 1.0.1 — SignalR Connection Stability Hotfix

## Fixed
- Added SignalR client keepalive ping frames so an otherwise idle authenticated
  connection is not treated as dead by the hub/server timeout policy.
- Keepalive is protocol-level SignalR traffic (`type: 6`), not
  `FetchPendingCommands` polling and not a FluxStore API request.
- Added stale-WebSocket callback protection so an old connection's late close
  event cannot clear a newer reconnect.
- Added one-shot disconnect handling to reduce duplicate disconnect/reconnect
  cascades from the same failed socket.
- A WebSocket close/error before authentication now completes the pending
  connection attempt immediately instead of waiting only for the request timeout.

## Credential safety / diagnostics
- Validates the documented combined server key shape locally without logging the
  credential value: GUID server ID plus a 32-character secret.
- `/smfluxbridge status` now shows the current transport stage and configured
  SignalR keepalive interval.
- Credential values remain excluded from logs, diagnostics and audit payloads.

## Preserved
- FluxStore protocol method names and argument ordering.
- `Authenticate` remains the first hub invocation.
- `PlayerJoin`, `PlayerLeave`, `FetchPendingCommands`, `ExecuteCommands`, and
  batched `AcknowledgeCommands` behavior.
- `RequireOnline`, `ExecutionOrder`, `Slots`, and `DelaySeconds` handling.
- Local command execution journal and manual-review behavior for uncertain state.
- No database migration and no LuckPerms changes.
